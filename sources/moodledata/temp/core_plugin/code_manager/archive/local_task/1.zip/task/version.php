<?php

defined('MOODLE_INTERNAL') || exit(0);

$plugin->version = 1;
$plugin->requires = 2020110903;
$plugin->component = 'local_task';